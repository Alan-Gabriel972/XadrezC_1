#include <stdio.h>
#include <string.h>
#include <locale.h>

void tabu(int tabuleiro[8][8]) {
    int x, y;
    for(x = 0; x < 8; x++) {
        for(y = 0; y < 8; y++){
            printf("%d ", tabuleiro[x][y]);
        };
        printf("\n");
    };
};
void movi(int tabuleiro[8][8], int x1, int y1, int x, int y) {
    printf("insira a peça de origem: \n");
    scanf("%d, %d", &y, &x);
    
    printf("insira a posição que deseja\n");
    scanf("%d, %d", &y1, &x1);
   
    if (tabuleiro[y1][x1] == 1) {
    printf("tem uma peça de mesmo tipo existente já !\n");
     tabuleiro[y][x] = tabuleiro[y1][x1];
    }
    if (tabuleiro[y1][x1] == 2) {
        printf("tem uma peça de mesmo tipo existente já !\n");
        tabuleiro[y][x] = tabuleiro[y1][x1];
    }
    else {
        tabuleiro[y1][x1] = tabuleiro[y][x];
        tabuleiro[y][x] = 0;
    }
    
};



int main() {
    
    int x1, y1, x, y;
    
    
    int tabuleiro[8][8] = {
        {1, 1, 1, 1, 1, 1, 1, 1},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {2, 2, 2, 2, 2, 2, 2, 2}
        };
    
    while(x > 8){
    tabu(tabuleiro);
    
    movi(tabuleiro, x1, y1, x, y);

    
        
    }
    
    
    return 0;
}